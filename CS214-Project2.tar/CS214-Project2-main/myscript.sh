echo Welcome
cd textFile
echo hello
cd textFile
echo hello
cd textFiletextFile
pwd
cd directary_that_doesnt_exist
cd
